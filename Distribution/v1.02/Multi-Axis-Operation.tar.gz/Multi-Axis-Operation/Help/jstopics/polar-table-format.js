hmLoadTopic({
hmKeywords:"importing,importing to polar table,polar file format,vectors,vectors polar table format",
hmTitle:"Polar Table File Format",
hmDescription:"The polar table file format is Comma-Separated Values (CSV) that is compatible with Excel (or other spreadsheet applications) as well as a simple text editor such as Notepad++.",
hmPrevLink:"vector-table-format.html",
hmNextLink:"command-line-options.html",
hmParentLink:"index.html",
hmBreadCrumbs:"Advanced Features",
hmTitlePath:"Advanced Features > Polar Table File Format",
hmHeader:"<h1 class=\"p_Heading1\" style=\"page-break-after: avoid;\"><span class=\"f_Heading1\">Polar Table File Format<\/span><\/h1>\n\r",
hmBody:"<p class=\"p_Normal\">The polar table file format is Comma-Separated Values (CSV) that is compatible with Excel (or other spreadsheet applications) as well as a simple text editor such as <a href=\"https:\/\/notepad-plus-plus.org\/\" target=\"_blank\" class=\"weblink\">Notepad++<\/a>.<\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r<p class=\"p_Normal\">The format is a file with a single-line, three column header and then subsequent rows of vector values in polar coordinates and optional dwell time for each in seconds. The format is illustrated below with a spreadsheet view on the left and a simple text editor view of the<span style=\"font-style: italic;\"> same file<\/span> on the right. As can be observed in the illustration, the CSV format is a simple text, comma-separated format.<\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r<p class=\"p_Normal\"><span style=\"font-weight: bold;\">Example: <\/span>The header text should be as shown below with the exception that if you wish to use kilogauss units for the field magnitude, change (T) to (kG). Specifying the units allows the polar table load function to properly identify (and convert if necessary) the field values.<\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r<p class=\"p_Normal\" style=\"text-align: center;\"><img alt=\"polar-example\" style=\"margin:0 auto 0 auto;width:58.3125rem;height:19.1250rem;border:none\" src=\".\/images\/polar-example.png\"\/><\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r"
})
