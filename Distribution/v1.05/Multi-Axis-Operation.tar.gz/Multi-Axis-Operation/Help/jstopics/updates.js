hmLoadTopic({
hmKeywords:"",
hmTitle:"Updates",
hmDescription:"The Magnet-DAQ is provided as a open-source application subject to the GPL verison 3 or later license.",
hmPrevLink:"automated-app-control-example-2.html",
hmNextLink:"license-terms.html",
hmParentLink:"index.html",
hmBreadCrumbs:"Support",
hmTitlePath:"Support > Updates",
hmHeader:"<h1 class=\"p_Heading1\" style=\"page-break-after: avoid;\"><span class=\"f_Heading1\">Updates<\/span><\/h1>\n\r",
hmBody:"<p class=\"p_Normal\">The Magnet-DAQ is provided as a open-source application subject to the GPL verison 3 or later license.<\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r<p class=\"p_Normal\">The latest source code and binaries distributions can be found on the <a href=\"https:\/\/bitbucket.org\/product\" target=\"_blank\" class=\"weblink\">BitBucket Cloud<\/a> at:<\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r<p class=\"p_Normal\"><a href=\"https:\/\/bitbucket.org\/americanmagneticsinc\/multi-axis-operation\" target=\"_blank\" class=\"weblink\">https:\/\/bitbucket.org\/americanmagneticsinc\/multi-axis-operation<\/a><\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r<p class=\"p_Normal\">Ready-to-use binaries are provided on the <a href=\"https:\/\/bitbucket.org\/americanmagneticsinc\/multi-axis-operation\/downloads\/\" target=\"_blank\" class=\"weblink\">Downloads<\/a> page for 64-bit versions of Windows 7\/8\/10\/11, Linux (Ubuntu 18.04 or later recommended), and Apple macOS 10.10 (Yosemite) or later.<\/p>\n\r<p class=\"p_Normal\">&nbsp;<\/p>\n\r<p class=\"p_Normal\">Users are encourage to check the site often for updates (check out the &quot;Watchers&quot; feature). Notification lists will not be maintained by AMI.<\/p>\n\r"
})
